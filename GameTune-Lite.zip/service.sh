#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/config.conf"
LOG="$MODDIR/gametune.log"
BACKUP="$MODDIR/anim_backup.txt"

log() { echo "$(date '+%F %T') $*" >> "$LOG"; }
: > "$LOG"

# Wait for the system to finish booting
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; done
sleep 20
log "Boot complete. Android SDK $(getprop ro.build.version.sdk)"

# Save original animation values once, so uninstall can restore them
if [ -n "$ANIM_SCALE" ]; then
  if [ ! -f "$BACKUP" ]; then
    {
      echo "WIN=$(settings get global window_animation_scale)"
      echo "TRANS=$(settings get global transition_animation_scale)"
      echo "DUR=$(settings get global animator_duration_scale)"
    } > "$BACKUP"
  fi
  settings put global window_animation_scale "$ANIM_SCALE"
  settings put global transition_animation_scale "$ANIM_SCALE"
  settings put global animator_duration_scale "$ANIM_SCALE"
  log "Animation scale set to $ANIM_SCALE"
fi

if [ -z "$GAME_PKGS" ]; then
  log "GAME_PKGS is empty - edit config.conf and add your game package names."
fi

for p in $GAME_PKGS; do
  if ! pm list packages | grep -q "^package:$p\$"; then
    log "SKIP $p (not installed)"
    continue
  fi

  cmd game mode "$MODE" "$p" >> "$LOG" 2>&1 && log "$p -> game mode $MODE"

  if [ "$MODE" = "performance" ] && { [ -n "$DOWNSCALE" ] || [ -n "$FPS" ]; }; then
    args="--mode 2"
    [ -n "$DOWNSCALE" ] && args="$args --downscale $DOWNSCALE"
    [ -n "$FPS" ] && args="$args --fps $FPS"
    cmd game set $args "$p" >> "$LOG" 2>&1 && log "$p -> cmd game set $args"
  fi

  if [ "$COMPILE" = "1" ]; then
    cmd package compile -m speed-profile -f "$p" >> "$LOG" 2>&1 && log "$p -> compiled (speed-profile)"
  fi
done

[ "$KILL_BG" = "1" ] && am kill-all >> "$LOG" 2>&1 && log "Background apps cleared"
log "Done."
