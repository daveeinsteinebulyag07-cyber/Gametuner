#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/config.conf"
BACKUP="$MODDIR/anim_backup.txt"

for p in $GAME_PKGS; do
  cmd game reset "$p"
  cmd game mode standard "$p"
done

if [ -f "$BACKUP" ]; then
  . "$BACKUP"
  for k in WIN:window_animation_scale TRANS:transition_animation_scale DUR:animator_duration_scale; do
    var=${k%%:*}; key=${k##*:}
    eval val=\$$var
    [ -z "$val" ] || [ "$val" = "null" ] && val=1.0
    settings put global "$key" "$val"
  done
else
  settings put global window_animation_scale 1.0
  settings put global transition_animation_scale 1.0
  settings put global animator_duration_scale 1.0
fi
